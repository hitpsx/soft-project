package picture;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.*;

public class test2 {
	private static picture Te=new picture();
	@Before
	public void test() {
		Te.Creat();
	}
	public void test2() {
		 
		String aim=Te.randomWalk(3);
		assertEquals("new->worlds worlds->to ",aim);
		
	}
	@Test
	public void test3() {

		String aim=Te.randomWalk(2);
		assertEquals("strange->new ",aim);
	}
	@Test
	public void test4() {
			 
		String aim=Te.randomWalk(9);
		assertEquals("",aim);
	}
	public void test5() {
		String aim=Te.randomWalk(0);
		assertEquals("to->explore explore->strange strange->new new->worlds worlds->to to->seek seek->out out->new new->life life->and and->new new->civilizations ",aim);
	}
}