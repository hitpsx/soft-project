package picture;
import java.util.*;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

import java.io.*;
public class picture {
    /*
     Define two hashmap

     map1 is the  (location of word) ->  word (like  0-> to)
     map2 is the word -> location of  word (like to-> 0)
    */
    static HashMap<String, String> map1 = new HashMap<String, String>();
    static HashMap<String, String> map2= new HashMap<String, String>();

    /*
     target is the set of the location of the word in order
     tabStr is the input which divided by space and each one is a word
     graph  is the struct to storage the grapg
    */
    static String[] target;
    static String[] tabStr;
    static int[][] graph;

    public void  GetMap() {
       String[] tab = new String[picture.target.length];
            int j = 0;
            String blank = "";

            for (int i = 0; i < picture.target.length; i++) {
                if (picture.map1.containsValue(picture.target[i]) == false) {
                    blank = j + "";
                    picture.map1.put(blank, picture.target[i]);
                    picture.map2.put(picture.target[i], blank);
                    j++;
                }
            }


            for (int i = 0; i < picture.target.length; i++) {
                blank = (picture.map2.get(picture.target[i])).toString();
                tab[i] = blank;
            }

            picture.tabStr = tab;
    }
    public void GetString() {
       try {
                File fil = new File("H:\\DataStruct\\test2.txt");
                FileInputStream br = new FileInputStream(fil);

                char ch;
                String data = "";

                for (int i = 0; i < fil.length(); i++) {
                    ch = (char) br.read();
                    data = data + ch;
                }

                br.close();

                data = data.trim().replaceAll("[^A-Za-z., \n?!:;��_(){}\"\'-]","")
                    .replaceAll("[^A-Za-z]"," ").replaceAll(" +"," ").toLowerCase();
                picture.target = data.split(" ");
            } catch (IOException e) {
                e.printStackTrace();
            }
    }
    /* Show graph and use the graphviz to paint the graph*/
    public static void showDirectedGraph(int[][] graph, String[] target) {

        GraphViz gViz = new GraphViz("G:\\nba",
                "F:\\Program Files (x86)\\Graphviz2.38\\bin\\dot.exe");
        int ch;
        int ch2;
        
        gViz.start_graph();

        for (int i = 0; i < (target.length - 1); i++) {
            ch = Integer.parseInt(tabStr[i]);
            ch2 = Integer.parseInt(tabStr[i + 1]);
            gViz.addln(map1.get(ch + "") + "->" + map1.get(ch2 + "")
            + "[label=" + (graph[ch][ch2] + "") + "]" + ";");
        }

        gViz.end_graph();

        try {
            gViz.run();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void Creat() {
      this.GetString();
        this.GetMap();
      int[][] graph = new int[picture.map1.size()][picture.map1.size()];
            int ch;
            int ch2;

            for (int i = 0; i < (picture.target.length - 1); i++) {
                ch = Integer.parseInt(picture.tabStr[i]);
                ch2 = Integer.parseInt(picture.tabStr[i + 1]);
                graph[ch][ch2]++;
            }

            picture.graph = graph;
    }


    /*Get the bridgeWord of name1 and name2 which main use by function of generateNewText */
    public static String GetBright(String name1, String name2) {
        String blank;
        String aim;
        blank = aim = "";

        String[] temp;
        int ch;
        int ch2;

        //Judge the name1 and name2 whether is exist
        if ((map1.containsValue(name1) == false) ||
                (map1.containsValue(name2) == false)) {
            return null;
        } else {
            ch = Integer.parseInt(map2.get(name1));
            ch2 = Integer.parseInt(map2.get(name2));

            //Get the bridgeWord
            for (int i = 0; i < map2.size(); i++) {
                if ((graph[ch][i] != 0) && (graph[i][ch2] != 0)) {
                    blank += (map1.get(i + "").toString() + " ");
                }
            }

            if ((blank == null) || blank.isEmpty()) {
                return null;
            } else {
                temp = blank.split(" ");

                for (int i = 0; i < temp.length; i++)
                    aim += (temp[i] + " ");
            }

            return aim;
        }
    }

    /*Get the queryBridgeWords of name1 and name2 which use by function queryBridgeWords */
    public static String queryBridgeWords(String name1, String name2) {
        String blank;
        String aim;
        int ch , ch2;
        String[] temp;

        blank = aim = "";

        if (map1.containsValue(name1) == false && map1.containsValue(name2)==false) /*Two case which name1 and name2 not exist*/ {
            aim = "No " + name1 + " " +"and "+ name2 + " in the graph!";
        }
        else if (map1.containsValue(name1) == false) {
          aim = "No " + name1 + " in the graph!";
        }
        else if (map1.containsValue(name2) == false) {
            aim = "No " + name2 + " in the graph!";
        }
        else {
            ch = Integer.parseInt(map2.get(name1));
            ch2 = Integer.parseInt(map2.get(name2));

            for (int i = 0; i < map2.size(); i++) {
                if ((graph[ch][i] != 0) && (graph[i][ch2] != 0)) {
                    blank += (map1.get(i + "").toString() + " ");
                }
            }

            if ((blank == null) || blank.isEmpty()) {
                aim = "No bridge words from " + name1 + " to " + name2 + "!";
            } else {
                temp = blank.split(" ");
                aim = "The bridge words from " + name1 + " to " + name2 +
                    " are: ";

                for (int i = 0; i < temp.length; i++)
                    aim += (temp[i] + " ");
            }
        }

        return aim;
    }

    /*Use the function of GetBright() and get the right txt*/
    public static String generateNewText(String input) {

      input = input.trim().replaceAll("[^A-Za-z., \n?!:;��_(){}\"\'-]","")
            .replaceAll("[^A-Za-z]"," ").replaceAll(" +"," ").toLowerCase();
        String[] test = input.split(" ");
        String[] test2;
        String aim,blank;

        aim = blank = "";
        blank = test[0] + " ";

        /*For word1 -> word2  use the function of GetBright()
          If  have bridgeword the  add it to blank (like word1->bridgeword->word2)
          else add directly to the string P (like word1->word2)
        */
        for (int i = 0; i < (test.length - 1); i++) {
            if ((GetBright(test[i], test[i + 1]) == null) ||
                    GetBright(test[i], test[i + 1]).isEmpty()) {
                blank += (test[i + 1] + " ");
            } else {
                aim = GetBright(test[i], test[i + 1]);
                test2 = aim.split(" ");
                if (test2.length > 1)
                {
                  Random random = new Random();
                  int h = random.nextInt(test2.length);
                    blank += (test2[h] + " " + test[i + 1] + " ");
                }
                else
                {
                  blank += aim + " " + test[i + 1] + " ";
                }
            }
        }

        return blank;
    }

    /*Use floyd to get the shortest path of any two points*/
    public static String ShortLine(String word1, String word2) {
       int ch,ch2,size;
         String blank = "";

         size = map2.size();
         if (map1.containsValue(word1) == false) /*Two case which word1 and word2 not exist*/ {
             blank = "No " + word1 + " in the graph!";
         } else if (map1.containsValue(word2) == false) {
             blank = "No " + word2 + " in the graph!";
         }
         else
         {
             ch = Integer.parseInt(map2.get(word1));
             ch2 = Integer.parseInt(map2.get(word2));

             int[][] P = new int[size][size];
             int[][] temp = new int[size][size];

             /* First creat a two-dimensional array(temp) which the same as graph
                because we will change the graph
                Next use floyd to get the result and creat a matrix(P)  which storage the intermediate nodes
                Final make string blank storage the final path and use graphviz to paint the graph
             */
             for (int i = 0; i < size; i++) {
                 for (int j = 0; j < size; j++) {
                     if (graph[i][j] != 0) {
                         temp[i][j] = graph[i][j];
                     } else if (i != j) {
                         temp[i][j] = 9999;
                     }
                 }
             }

             for (int i = 0; i < size; i++) {
                 for (int j = 0; j < size; j++) {
                     if (temp[i][j] != 9999) {
                         P[i][j] = j;
                     } else {
                         P[i][j] = 0;
                     }
                 }
             }

             for (int k = 0; k < size; ++k) {
                 for (int i = 0; i < size; ++i) {
                     for (int j = 0; j < size; ++j) {
                         if ((temp[i][k] + temp[k][j]) < temp[i][j]) {
                             temp[i][j] = temp[i][k] + temp[k][j];
                             P[i][j] = P[i][k];
                         }
                     }
                 }
             }

             int next = P[ch][ch2];

             if (next == 0) {
                 blank = "No path from " + word1 + " to " + word2 + "!";
             } else {
                 GraphViz gViz = new GraphViz("G:\\nba",
                         "F:\\Program Files (x86)\\Graphviz2.38\\bin\\dot.exe");

                 gViz.start_graph();

                 for (int i = 0; i < (tabStr.length - 1); i++)
                     gViz.addln(target[i] + "->" + target[i + 1]);

                 blank = map1.get(ch + "").toString();
                 gViz.addln(blank + "[color=red]" + ";");
                 blank += "->";
                 gViz.addln(map1.get(ch + "").toString() + "->" + map1.get(ch2 + "").toString() + "[color=red]" + "[label=" + temp[ch][ch2] + "]" + ";");
                 while (next != ch2) {
                     blank += (map1.get(next + "") + "->");
                     next = P[next][ch2];
                 }

                 blank = blank + map1.get(ch2 + "").toString();
                 gViz.addln(map1.get(ch2 + "").toString() + "[color=red]" + ";");
                 gViz.addln(blank + "[color=blue]" + ";");
                 gViz.end_graph();

                 try {
                     gViz.run();
                 } catch (Exception e) {
                     e.printStackTrace();
                 }
                 try {
                 String cmdText = "cmd /c start " + "G:\\nba\\temp.gif";
                 Runtime.getRuntime().exec(cmdText);
                 } catch (IOException e) {
                 e.printStackTrace();
                 }
             }
         }

         return blank;
    }
    
    public static void Write_txt(String blank) {
    	 try {
             File file = new File("G:\\nba\\tete.txt");
             PrintStream ps = new PrintStream(new FileOutputStream(file));
             ps.println(blank);
           } catch (FileNotFoundException e) {
                 e.printStackTrace();
         }
    }
    public static String randomWalk(int h) {
   	 Random random = new Random();

        String blank = "";
        String tmp = "";

        int k = 0;
        //int h = random.nextInt(map1.size());
        int Y[][] = new int[map1.size()][map1.size()];
        while (true)
        {
            for (int i = 0;i < map1.size();i++) {
                if (graph[h][i] != 0 && Y[h][i] == 0)
                {
                     Y[h][i] = 1;
                     tmp = map1.get(h + "") + "->" + map1.get(i + "") + " ";
                     blank += tmp;
                     System.out.println("Yes/Not?");
                     Scanner sc=new Scanner(System.in);
             		 tmp=sc.nextLine();
             		 if(tmp.equals("Y")) {
             			 h=i;
             			 break;
             		 }
             		 else {
             			 Write_txt(blank);
             			 return blank;
             		 }
                }
                else
                {
                    k++;
                }
            }
            if(k==map1.size()) break;
            else   k=0;
        }
        Write_txt(blank);
        return blank;
   }
    public static void main(String[] args) {
        picture Te=new picture();
        Te.Creat();
        System.out.print(Te.randomWalk(3));
  }
}
class GraphViz {
    private String runPath = "";
    private String dotPath = "";
    private String runOrder = "";
    private String dotCodeFile = "dotcode.txt";
    private String resultGif = "temp";
    private StringBuilder graph = new StringBuilder();
    Runtime runtime = Runtime.getRuntime();

    public GraphViz(String runPath, String dotPath, String nameGif) {
        this.runPath = runPath;
        this.dotPath = dotPath;
        this.resultGif = nameGif;
    }

    public GraphViz(String runPath, String dotPath) {
        this.runPath = runPath;
        this.dotPath = dotPath;
    }

    public void run() {
        File file = new File(runPath);
        file.mkdirs();
        writeGraphToFile(graph.toString(), runPath);
        creatOrder();

        try {
            runtime.exec(runOrder);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void creatOrder() {
        runOrder += (dotPath + " ");
        runOrder += runPath;
        runOrder += ("\\" + dotCodeFile + " ");
        runOrder += "-T gif ";
        runOrder += "-o ";
        runOrder += runPath;
        runOrder += ("\\" + resultGif + ".gif");
    }

    public void writeGraphToFile(String dotcode, String filename) {
        try {
            File file = new File(filename + "\\" + dotCodeFile);

            if (!file.exists()) {
                file.createNewFile();
            }

            FileOutputStream fos = new FileOutputStream(file);
            fos.write(dotcode.getBytes());
            fos.close();
        } catch (java.io.IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public void add(String line) {
        graph.append("\t" + line);
    }

    public void addln(String line) {
        graph.append("\t" + line + "\n");
    }

    public void addln() {
        graph.append('\n');
    }

    public void start_graph() {
        graph.append("digraph G {\n");
    }

    public void end_graph() {
        graph.append("}");
    }
}
/*

@Test
	public void test2() {
		String aim=Te.queryBridgeWords("big","a");
		assertEquals("No a in the graph! ",aim);

	}
	@Test
	public void test3() {
	String aim=Te.queryBridgeWords("a","time");
	assertEquals("No a in the graph! ",aim);
	}
	@Test
	public void test4() {
	String aim=Te.queryBridgeWords("big","hello");
	assertEquals("No hello in the graph! ",aim);
	}
	@Test
	public void test5() {
	String aim=Te.queryBridgeWords("a","hello");
	assertEquals("No a and hello in the graph! ",aim);
	}
*/
/*
public void test2() {
			 
		String aim=Te.randomWalk(3);
		assertEquals("new->worlds worlds->to ",aim);
		
	}
	@Test
	public void test3() {

		String aim=Te.randomWalk(2);
		assertEquals("strange->new ",aim);
	}
	@Test
	public void test4() {
			 
		String aim=Te.randomWalk(9);
		assertEquals("",aim);
	}
	public void test5() {
		String aim=Te.randomWalk(0);
		assertEquals("to->explore explore->strange strange->new new->worlds worlds->to to->seek seek->out out->new new->life life->and and->new new->civilizations ",aim);
	}
}*/